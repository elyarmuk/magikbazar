package com.ecommerce.magikbazar.web.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagikbazarWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagikbazarWebAppApplication.class, args);
	}

}
